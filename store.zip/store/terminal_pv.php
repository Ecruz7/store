<?php require_once 'encabezado.php'; ?>
<script src="./controlador/sell_product.js"></script>
  
<body ng-controller="sellProductCtrl">

	<div id="content" >
		<div class="row">
	 
			<h3 >Punto de venta</h1>
			<form class="form-horizontal" name="user2">	
				<div class="form-group">
			
					<div class="col-sm-3" >
						<input class="form-control" type = "text" name="barcode" ng-model="product.bar_code" placeholder="Codigo producto" >
					</div>
					<div class="col-sm-2">
						<button  ng-click="addProduct()" class="btn btn-primary"> 
							<span class="glyphicon glyphicon-floppy-disk"></span> Guardar</button>
					</div>
					
				</div>
			</form>
			
			
			<!-- Trigger the modal with a button -->
	  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
		Buscar producto
	  </button>
	  
	    <!-- Modal -->
		<div class="modal" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="false">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
			  <div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Busqueda de productos</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
				  <span aria-hidden="true">&times;</span>
				</button>
			  </div>
			  <div class="modal-body">
					<input class="form-control" type = "text"  ng-model="product.product_id"  placeholder="Nombre del producto" required>.
					<table class="table table-hover table-striped">
					     <thead>
						   <tr>
							  <th class="text-center">Producto</th>
						   </tr>
					     </thead>

					     <tbody>
						   <tr ng-repeat="t in products_search">
						      <td class="text-center" style="display:none;"><input class="form-control" 
							  type = "text"  ng-model="t.product_id"></td>
							  <td class="text-center" ><input class="form-control" 
							  type = "text"  ng-model="t.name"  disabled></td>
							  <td class="text-center"><button ng-click="setBarcode_input(t)" data-dismiss="modal".
							  class="btn btn-success">
							  <span class="glyphicon glyphicon-plus-sign"></span></button></td>
						   </tr>
					     </tbody>	
			        </table>
					
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-secondary"  ng-click="clean()" data-dismiss="modal" >Close</button>
				
				<button  ng-click="consultar()" class="btn btn-primary"> 
				<span class="glyphicon glyphicon-floppy-disk"></span> Buscar</button>
				
			  </div>
			</div>
		  </div>
		</div>	
			
			<div class="row" style="overflow:scroll; height:300px;">
			
			<table class="table table-hover table-striped">
			 <thead>
			 	<tr>
			 		<th class="text-center">Producto</th>
					<th class="text-center">Precio unitario</th>
					<th class="text-center">Cantidad</th>
					<th class="text-center">Total</th>
			 		<th class="text-center"><span class="glyphicon glyphicon-pencil"></span></th>
			 		<th class="text-center"><span class="glyphicon glyphicon-trash"></span></th>
			 	</tr>
			 </thead>

			 <tbody>
			 	<tr ng-repeat="t in products">
				   <td class="text-center" style="display:none;"><input class="form-control" 
					type = "text"  ng-model="t.product_id"></td>
			 		<td class="text-center"><input class="form-control" 
					type = "text"  ng-model="t.name" disabled></td>
			 		<td class="text-center"><input class="form-control" 
					type = "text"  ng-model="t.price" disabled></td>
					<td class="text-center"><input class="form-control" 
					type = "text"  ng-model="t.amount" ></td>
					<td class="text-center"><input class="form-control" 
					type = "text"  ng-model="t.total" disabled></td>
			 		<td class="text-center"><button ng-click="editProduct(t)" class="btn btn-success">
					<span class="glyphicon glyphicon-pencil"></span></button></td>
			 		<td class="text-center"><button ng-click="eliminar(t)" class="btn btn-danger">
					<span class="glyphicon glyphicon-trash"></span></button></td>
			 	</tr>
			 </tbody>	
			</table>
			
			</div>
			
			<form class="form-horizontal" name="user2">	
				<div class="form-group">
					<label class="col-sm-1 control-label"> Total  </label>
					
					<div class="col-sm-1" >
						<label class="form-control" id="lblTotal" >{{total}}</label>
					</div>
					
					<label class="col-sm-1 control-label"> Paga con </label>
					
					<div class="col-sm-1" >
						<input class="form-control" type = "text"  ng-model="sell.cash" placeholder="pago" required>
					</div>
					
					<label class="col-sm-1 control-label"> </label>
					<div class="col-sm-1">
						<button  ng-click="saveSell()" class="btn btn-primary"> 
							<span class="glyphicon glyphicon-floppy-disk"></span> Cobrar</button>
					</div>
					<div class="col-sm-1">
						<button  ng-click="cancellSell()" class="btn btn-primary"> 
							<span class="glyphicon glyphicon-floppy-disk"></span> Cancelar venta</button>
					</div>
					

				</div>
			</form>
		
			</div>
			
				
					<div class="col-sm-1">
						<button  class="btn btn-primary"> 
							<span class="glyphicon glyphicon-floppy-disk"></span> <a href="./reports/ticket.php"></button>
					</div>
			
		</div>
		
		
	</body>
	<?php require_once 'pie.php'; ?>