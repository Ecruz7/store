<?php 

	//getting the dboperation class
	require_once '../includes/DBOperationActivity.php';

	//function validating all the paramters are available
	//we will pass the required parameters to this function 
	function isTheseParametersAvailable($params){
		//assuming all parameters are available 
		$available = true; 
		$missingparams = ""; 
		foreach($params as $param){
			if(!isset($_POST[$param]) || strlen($_POST[$param])<=0){
				$available = false; 
				$missingparams = $missingparams . ", " . $param; 
			}
		}
		
		//if parameters are missing 
		if(!$available){
			$response = array(); 
			$response['error'] = true; 
			$response['message'] = 'Parameters ' . substr($missingparams, 1, strlen($missingparams)) . ' missing';
			//displaying error
			echo json_encode($response);
			//stopping further execution
			die();
		}
	}
	//an array to display response
	$response = array();
	//if it is an api call 
	//that means a get parameter named api call is set in the URL 
	//and with this parameter we are concluding that it is an api call
	if(isset($_GET['apicall'])){
		switch($_GET['apicall']){
			//the READ operation
			//if the call is getActivities
			case 'getActivities':
			isTheseParametersAvailable(array('topic_id','user_course_id'));
			if(isset($_POST['topic_id']) && isset($_POST['user_course_id']) ){
			$db = new DbOperation();
				$response['error'] = false; 
				$response['message'] = 'Peticion realizada';
				$response['data'] = $db->getActivities($_POST['topic_id'],$_POST['user_course_id']);
			}
			else
			{
					$response['error'] = true; 
					$response['message'] = 'Nothing to get, provide an id please';
			}
			break; 
			//the UPDATE operation
			case 'getChoises':
			isTheseParametersAvailable(array('activity_id','activity_type_id'));
		
			if(isset($_POST['activity_id']) && isset($_POST['activity_type_id'])){
			$db = new DbOperation();
				$response['error'] = false; 
				$response['message'] = 'choises';
				$response['data'] = $db->getChoises($_POST['activity_id'],$_POST['activity_type_id']);
			}
			else
			{
					$response['error'] = true; 
					$response['message'] = 'Nothing to get, provide an id please';
			}
			break;
			
			case 'getQuestions':
			isTheseParametersAvailable(array('activity_id','activity_type_id'));
			if(isset($_POST['activity_id']) && isset($_POST['activity_type_id'])){
				$db = new DbOperation();
				$response['error'] = false; 
				$response['message'] = 'questions';
				$response['data'] = $db->getQuestions($_POST['activity_id'],$_POST['activity_type_id']);
			}
			else
			{
					$response['error'] = true; 
					$response['message'] = 'Nothing to get, provide an id please';
			}
			break;
			
			case 'getAudioData':
			isTheseParametersAvailable(array('activity_id','activity_type_id'));
			if(isset($_POST['activity_id']) && isset($_POST['activity_type_id'])){
			$db = new DbOperation();
			$response['error'] = false; 
			$response['message'] = 'questions';
			$response['data'] = $db->getAudioData($_POST['activity_id'],$_POST['activity_type_id']);
			}
			else
			{
					$response['error'] = true; 
					$response['message'] = 'Nothing to get, provide an id please';
			}
			break;
			
			case 'updateActivity':
				isTheseParametersAvailable(array('user_activity_id'));
				if(isset($_POST['user_activity_id'])){
				$db = new DbOperation();
				$result = $db->updateActivity($_POST['user_activity_id']);
				if($result){
					$response['error'] = false; 
					$response['message'] = 'updateActivity';
				}else{
					$response['error'] = true; 
					$response['message'] = 'Some error occurred please try again';
				}
			}
			break; 						case 'updateActivity_tries':				isTheseParametersAvailable(array('user_activity_id','tries'));				if(isset($_POST['user_activity_id'])){				$db = new DbOperation();				$result = $db->updateActivity_tries($_POST['user_activity_id'],$_POST['tries']);				if($result){					$response['error'] = false; 					$response['message'] = 'updateActivity';				}else{					$response['error'] = true; 					$response['message'] = 'Some error occurred please try again';				}			}			break; 
		}
		
	}else{
		//if it is not api call 
		//pushing appropriate values to response array 
		$response['error'] = true; 
		$response['message'] = 'Invalid API Call';
	}
	
	//displaying the response in json structure 
	echo json_encode($response);
	
?>