<?php
header("Access-Control-Allow-Origin: *");  
header("Content-Type: application/json");
error_reporting(E_ALL);
require_once 'conexion.php';
$obj = json_decode(file_get_contents("php://input"));
$stmt = $db->prepare("SELECT * FROM topic where codigo = ?");
$stmt->bind_param('s',$obj->codigo);
$stmt->bind_result($codigo,$nombre,$precio);
$stmt->execute();
$arr = array();
if($stmt->fetch()){
$arr = array('codigo' =>$codigo,
	'nombre' =>$nombre,
    'precio' => $precio);
}
$stmt->close();
echo json_encode($arr);
?>