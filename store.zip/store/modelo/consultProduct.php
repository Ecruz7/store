<?php
header("Access-Control-Allow-Origin: *");  
header("Content-Type: application/json");
error_reporting(E_ALL);
require_once 'conexion.php';
$obj = json_decode(file_get_contents("php://input"));

if(!empty($obj->bar_code)){
$result  = $db->query("SELECT * FROM product where bar_code =$obj->bar_code");	
		if (!$result ) {
			return  $result;
		}
		
		$fila = mysqli_fetch_array( $result );
		$data = array(); 		
		$result->free();		
	
echo json_encode($fila);
}else
{
	echo "null";
}
?>