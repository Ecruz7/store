<?php
error_reporting(E_ALL);
require_once 'conexion.php';
$result  = $db->query("SELECT * FROM activities");	
if (!$result ) {
	return  false;
}
$data = array(); 		/* obtener un array asociativo */			
while($fila = mysqli_fetch_array( $result ) )
{
$data[] = array(
	'activity_id' =>$fila['activity_id'],
	'fk_topic_id' =>$fila['fk_topic_id'],
	'fk_activity_type_id' =>$fila['fk_activity_type_id'],
    'activity_name' =>$fila['activity_name']);
}
echo json_encode($data);
?>