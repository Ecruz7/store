<?php
error_reporting(E_ALL);
require_once 'conexion.php';
$result  = $db->query("SELECT * FROM category");	
if (!$result ) {
	return  false;
}
$data = array(); 		/* obtener un array asociativo */			
while($fila = mysqli_fetch_array( $result ) )
{
$data[] = array(
	'category_id' =>$fila['category_id'],
    'name' =>$fila['name']);	
}
echo json_encode($data);
?>