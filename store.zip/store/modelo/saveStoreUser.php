<?php
header("Access-Control-Allow-Origin: *");  
header("Content-Type: application/json");
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
//header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
//header("Allow: GET, POST, OPTIONS, PUT, DELETE");
error_reporting(E_ALL);
require_once 'conexion.php';
$obj = json_decode(file_get_contents("php://input"));
$stmt = $db->prepare("INSERT INTO usuario (usuario,pass,nombre,rol)
 VALUES(?,?,?,?)");
$pass = md5($obj->pass);
$stmt->bind_param('ssss',$obj->usuario,$pass,$obj->nombre,$obj->rol);
$stmt->execute();
$stmt->close();
echo "Registro Exitoso";
?>