<?php
error_reporting(E_ALL);
require_once 'conexion.php';
$result  = $db->query("SELECT * FROM activity_type");	
if (!$result ) {
	return  false;
}
$data = array(); 		/* obtener un array asociativo */			
while($fila = mysqli_fetch_array( $result ) )
{
$data[] = array(
	'activity_type_id' =>$fila['activity_type_id'],
    'type_activity_name' =>$fila['type_activity_name']);
	
	//seccion que permite la creacion de los directorios de los tipos de actividad en caso de que no existan
	settype($fila['activity_type_id'], 'string');
	$directorio =$fila['activity_type_id'];
	if (!is_dir('../contents/'.$directorio) ){
	mkdir('../contents/'.$directorio, 0777);
	}	
}
echo json_encode($data);
?>