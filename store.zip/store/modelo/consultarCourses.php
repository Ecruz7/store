<?php
error_reporting(E_ALL);
require_once 'conexion.php';
$result  = $db->query("SELECT * FROM course");	
if (!$result ) {
	return  false;
}
$data = array(); 		/* obtener un array asociativo */			
while($fila = mysqli_fetch_array( $result ) )
{
$data[] = array(
	'course_id' =>$fila['course_id'],
	'fk_asignature_id' =>$fila['fk_asignature_id'],
    'name_course' =>$fila['name_course']);
}
echo json_encode($data);
?>