<?php
echo md5("123");
?>