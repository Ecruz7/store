<?php
error_reporting(E_ALL);
require_once 'conexion.php';
$stmt = $db->prepare("SELECT * FROM store_user");
$stmt->bind_result($user_name,$pass,$name,$type);
$stmt->execute();
$arr = array();
while($stmt->fetch()){
$arr[] = array('user_name' =>$user_name,
	'password'=>$pass,
	'name' =>$name,
    'user_type' => $type);
}
$stmt->close();
echo json_encode($arr);
?>