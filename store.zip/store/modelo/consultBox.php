<?php
header("Access-Control-Allow-Origin: *");  
header("Content-Type: application/json");
error_reporting(E_ALL);
require_once 'conexion.php';
$obj = json_decode(file_get_contents("php://input"));

$stmt="SELECT max(box_id) as box_id from box";
$result  = $db->query($stmt);	
	if (!$result ) 
	{
		return  $result;
	}
	
	$fila = mysqli_fetch_array( $result );	
	session_start();
	$_SESSION['box_id']=$fila['box_id'];	
	echo $fila['box_id'];

?>