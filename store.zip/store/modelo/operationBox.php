<?php
header("Access-Control-Allow-Origin: *");  
header("Content-Type: application/json");
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
//header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
//header("Allow: GET, POST, OPTIONS, PUT, DELETE");
error_reporting(E_ALL);
require_once 'conexion.php';
$obj = json_decode(file_get_contents("php://input"));

$stmt0 = "SELECT * FROM store_user where user_name='$obj->user_name' AND password='$obj->password' and user_type=1";

$result=$db->query($stmt0 );

if($result)
{
	$fila = mysqli_fetch_array( $result );	
	$user_id=$fila['user_id'];
    $stmt ="INSERT INTO box (user_id,cash) VALUES($user_id,$obj->cash)";
    $result=$db->query($stmt );
    if($result)
	{
		session_start(); 
		$_SESSION['box_id']=mysqli_insert_id($db);  
	}
	else
	{
	    echo "No se inserto el registro correctamente.";
	}
 
}
else
{
  echo "Se ha producido un error";
}
echo $_SESSION['box_id'];
?>