<?php
header("Access-Control-Allow-Origin: *");  
header("Content-Type: application/json");
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
//header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
//header("Allow: GET, POST, OPTIONS, PUT, DELETE");
error_reporting(E_ALL);
require_once 'conexion.php';
$obj = json_decode(file_get_contents("php://input"));
session_start();
$sell_id=intval($_SESSION['sell_id']);
$db->autocommit(false);
$result="";
try {

foreach($obj as $item) {		
$stmt = "INSERT INTO product_sell (product_id,amount,price,sell_id)
VALUES($item->product_id,$item->amount,$item->price,$sell_id)";
$db->query($stmt );
$db->commit();
}

 echo mysqli_insert_id($db);
 
} catch (Exception $e) {
    $db->rollback();
    $result= $e->getMessage();
}

echo $result;
?>