<?php
header("Access-Control-Allow-Origin: *");  
header("Content-Type: application/json");
error_reporting(E_ALL);
require_once 'conexion.php';
$result=false;
$obj = json_decode(file_get_contents("php://input"));
if(!empty($obj->name) and !empty($obj->category_id) ){
	$result  = $db->query("SELECT * FROM product where name like '%$obj->name%' and category_id=$obj->category_id");	
}else if(!empty($obj->category_id)){
	$result  = $db->query("SELECT * FROM product where category_id=$obj->category_id");	
}else if(!empty($obj->name)){
	$result  = $db->query("SELECT * FROM product where name like '%$obj->name%'");	
}else {
	$result  = $db->query("SELECT * FROM product");	
}


if (!$result ) {
	return  false;
}
$data = array(); 		/* obtener un array asociativo */			
while($fila = mysqli_fetch_array( $result ) )
{
$data[] = array(
    'product_id' =>$fila['product_id'],
	'name' =>$fila['name'],
	'bar_code' =>$fila['bar_code'],
    'inventary' =>$fila['inventary'],
	'price' =>$fila['price'],
	'category_id' =>$fila['category_id']);
}
echo json_encode($data);
?>