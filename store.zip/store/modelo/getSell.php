<?php
header("Access-Control-Allow-Origin: *");  
header("Content-Type: application/json");
header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
//header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
//header("Allow: GET, POST, OPTIONS, PUT, DELETE");
error_reporting(E_ALL);
require_once 'conexion.php';
$obj = json_decode(file_get_contents("php://input"));
session_start();
$box_id=intval($_SESSION['box_id']);
$user_id=intval($_SESSION['user_id']);

$stmt ="select * from where";
$result=0;
if($db->query($stmt ))
{	
	$_SESSION['sell_id']=mysqli_insert_id($db);
	$result=mysqli_insert_id($db);
}else
{
	$result= "No se realizo la insercion";
}
echo $result;
?>