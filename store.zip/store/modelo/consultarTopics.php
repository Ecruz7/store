<?php
error_reporting(E_ALL);
require_once 'conexion.php';
$result  = $db->query("SELECT * FROM topic");	
if (!$result ) {
	return  false;
}
$data = array(); 		/* obtener un array asociativo */			
while($fila = mysqli_fetch_array( $result ) )
{
$data[] = array(
	'topic_id' =>$fila['topic_id'],
	'topic_name' =>$fila['topic_name'],
    'topic_course_id' =>$fila['topic_course_id']);
}
echo json_encode($data);
?>