<?php
error_reporting(E_ALL);
require_once 'conexion.php';
$result  = $db->query("SELECT * FROM store_user where user_name='$_POST[user_name]' AND password='$_POST[password]' and user_type=1");

if (!$result ) {
	header("Location: ../index.php");
}
else{
	$data = array(); 		/* obtener un array asociativo */	
	$user_name="";
	while($fila = mysqli_fetch_array( $result ) )
	{
	  //Ahora $fila tiene la primera fila de la consulta, pongamos que tienes
	  //un campo en tu DB llamado NOMBRE, así accederías
	  $user_name=$fila['user_name'];
	  $user_id=$fila['user_id'];
	}
  $result->free();
  if($user_name!=""){
  session_start();
  $_SESSION['user_name']=$user_name;
  $_SESSION['rol']="admin";
  $_SESSION['user_id']=$user_id;
  header("Location: ../menuAdmin.php");
  }else{
      	header("Location: ../index.php");
  }
  
}
?>