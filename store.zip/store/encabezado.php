<?php
session_start();
if(isset($_SESSION['user_name']) && $_SESSION['rol']=="admin"){
}
else{
  header("Location: ./index.php");
}
?>
<html lang="en"  ng-app="app">
<head>
 <meta http-equiv="Content-type" content="text/html; charset=utf-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <title>AMM</title>
 <!-- Bootstrap -->
 <link rel="icon" type="image/png" href="./img/neto.png" />
 <link rel="stylesheet" href="./css/bootstrap.min.css" >
 <link rel="stylesheet" href="./css/margenes.css" >
 <script src="./controlador/jquery.js"></script>
 <script src="./css/bootstrap.min.js"></script>
 <script src="./controlador/angular.min.js"></script>
 
  
  
</head>

<header>
 <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
  <div class="container-fluid">
    <div class="navbar-header">
     <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myNavbar">
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>                        
     </button>  
     <IMG class="navbar-brand" SRC="./img/AMM2.png"> </IMG>
     <a class="navbar-brand" href="">AMM</a>
    </div>
  <div class="collapse navbar-collapse" id="myNavbar">
   <ul class="nav navbar-nav">
   <li class=""><a href=""><span class="glyphicon glyphicon-home.glyphicon"></span> inicio</a></li>     
	<li class="dropdown">
		<a class="dropdown-toggle" data-toggle="dropdown" href="#">Menu punto de venta <span class="caret"></span></a>
		
		
		
		<ul class="dropdown-menu">
			<li class=""><a href="./operationBox.php"><span class="glyphicon glyphicon-home.glyphicon"></span> Corte de caja</a></li>   
			<li class=""><a href="./terminal_pv.php"><span class="glyphicon glyphicon-home.glyphicon"></span> Terminal punto de venta</a></li>   
		</ul>	
    </li>

	<li class="dropdown">
		<a class="dropdown-toggle" data-toggle="dropdown" href="#">Menu productos<span class="caret"></span></a>
		<ul class="dropdown-menu">
			<a href="./product.php"> <span class="glyphicon glyphicon-home.glyphicon"></span>Productos</a>
		</ul>	
    </li>
	
	
	<li class="dropdown">
		<a class="dropdown-toggle" data-toggle="dropdown" href="#">Ventas<span class="caret"></span></a>
		<ul class="dropdown-menu">
			<a href="./sell.php"> <span class="glyphicon glyphicon-home.glyphicon"></span>Ventas</a>
		</ul>	
    </li>
	
	<li><a href="">Acerca de</a></li>
    
	</ul>
      <ul class="nav navbar-nav navbar-right">
       <li><a href="#"><?php echo $_SESSION['user_name']; ?></a></li>
       <li><a href="./modelo/salir.php">Cerrar Sesion</a></li>
      </ul>

    </div>

   </div>
  </nav>
</header>

</html>