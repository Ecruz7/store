la carpeta de choises contienen las opciones de las preguntas 
la carpeta questions contienen las preguntas
esta siempre sera la estructura para el tipo de actividad cuestionario que esta en la base de datos