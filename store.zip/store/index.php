<?php
session_start();
if(isset($_SESSION['user_name']) && $_SESSION['rol']=="admin"){
	 header("Location: ./encabezado.php");
}
?>
<!DOCTYPE html>
<html lang="en"  ng-app="app">
<head>
 <meta http-equiv="Content-type" content="text/html; charset=utf-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <title>Punto de venta</title>
 <!-- Bootstrap -->
 <link rel="icon" type="image/png" href="./img/neto.png" />
 <link rel="stylesheet" href="./css/bootstrap.min.css" >
 <link rel="stylesheet" href="./css/margenes.css" >
 <script src="./controlador/jquery.js"></script>
 <script src="./css/bootstrap.min.js"></script>
 <script src="./controlador/angular.min.js"></script>
</head>

<header>
 <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
  <div class="container-fluid">
    <div class="navbar-header">
     <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#myNavbar">
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>                        
     </button>  
     <IMG class="navbar-brand" SRC="./img/AMM2.png"> </IMG>
     <a class="navbar-brand" href=""> Inicio</a>
    </div>

    <div class="collapse navbar-collapse" id="myNavbar">
      <form class="navbar-form navbar-right" action="./modelo/login.php" method="post" role="form">
      <div class="input-group">
       <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
      <input type="text" class="form-control" name ="user_name" placeholder="Usuario" required>
      </div>
      <div class="input-group">
       <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
      <input type="password" class="form-control" name ="password" placeholder="Contraseña" required>
      </div>
      <button type="submit" class="btn btn-info">Iniciar sesión</button>
      </form>
   </div>
   </div>
  </nav>
</header>
<script src="./controlador/index.js"></script>
<body ng-controller="indexCtrl">
 <div id="content" >
 
 <div class ="row">
 
  <div class="col-md-12 text-center">
   <h2>¡Bienvenido!</h2>
  </div>

  <div class="col-md-12 text-center">
    <div class="col-md-4 text-center">  
     <img src="./img/AMM0.png" class="img-responsive">
   </div>
   <div class="col-md-8 text-center">  
    <img src="./img/AMM1.png" class="img-responsive">
   </div>
  </div>
 
 </div>

 </div>
</body>

<?php require_once 'pie.php'; ?>
</html>