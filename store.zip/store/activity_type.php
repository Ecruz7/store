<?php require_once 'encabezado.php'; ?>
<script src="./controlador/activity_type.js"></script>
<body ng-controller="ActivityTypeCtrl">
	<div id="content" >
		<div class="row">
			<h3 >Tipos de actividades</h1>
			<form class="form-horizontal" name="user2">	
				<div class="form-group">
					<label class="col-sm-2 control-label">Tipo de actividad</label>
					<div class="col-sm-2" >
						<input class="form-control" type = "text"  ng-model="activity_type.type_activity_name" placeholder="Nombre" required>
					</div>
					<div class="col-sm-2">
						<button  ng-click="guardar()" class="btn btn-primary"> 
							<span class="glyphicon glyphicon-floppy-disk"></span> Guardar</button>
						</div>
					</div>
			</form>
			
			<table class="table table-hover table-striped">
			 <thead>
			 	<tr>
			 		<th class="text-center">Nombre del tipo de actividad</th>
			 		<th class="text-center"><span class="glyphicon glyphicon-pencil"></span></th>
			 		<th class="text-center"><span class="glyphicon glyphicon-trash"></span></th>
			 	</tr>
			 </thead>

			 <tbody>
			 	<tr ng-repeat="act in activity_types">
			 		<td class="text-center"><input class="form-control" 
					type = "text"  ng-model="act.type_activity_name"></td>
			 		<td class="text-center"><button ng-click="modificar(act)" class="btn btn-success">
					<span class="glyphicon glyphicon-pencil"></span></button></td>
			 		<td class="text-center"><button ng-click="eliminar(act)" class="btn btn-danger">
					<span class="glyphicon glyphicon-trash"></span></button></td>
			 	</tr>
			 </tbody>	
			</table>

			</div>
		</div>
	</body>
	<?php require_once 'pie.php'; ?>