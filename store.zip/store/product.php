<?php require_once 'encabezado.php'; ?>
<script src="./controlador/product.js"></script>
<body ng-controller="productCtrl">
	
	<div id="content" >
		<div class="row">
			<h3>Registro de productos</h3>
			<form class="form-horizontal" name="products">	
				<div class="form-group">
					<label class="col-sm-2 control-label"> Nombre producto </label>
					<div class="col-sm-2" >
						<input class="form-control" type = "text"  ng-model="product.name" placeholder="ingresa un nombre" required>
					</div>
					<label class="col-sm-2 control-label"> Codigo de barras </label>
					<div class="col-sm-2" >
						<input class="form-control" type = "text"  ng-model="product.bar_code" placeholder="ingresa un codigo" required>
					</div>
					
					<label class="col-sm-2 control-label"> Existencia </label>
					<div class="col-sm-2" >
						<input class="form-control" type = "text"  ng-model="product.inventary" placeholder="ingresa un valor" required>
					</div>
				</div>
				
				<div class="form-group">
			
					<label class="col-sm-2 control-label"> Precio </label>
					<div class="col-sm-2" >
						<input class="form-control" type = "text"  ng-model="product.price" placeholder="ingresa un valor" required>
					</div>
					
					<label class="col-sm-2 control-label"> Categoria </label>
				    <div class="col-sm-2">
						<select ng-model="selectedCategory" ng-options="item.category_id as item.name for item in category " class="form-control" required>
						</select>
					</div>
					
					<label class="col-sm-2 control-label"> Unit </label>
				    <div class="col-sm-2">
						<select ng-model="selectedUnit" ng-options="item.unit_id as item.name for item in unit " class="form-control" required>
						</select>
					</div>
				
					<label class="col-sm-2 control-label"> </label>
					<div class="col-sm-2">
						<button  ng-click="guardar()" class="btn btn-primary"> 
							<span class="glyphicon glyphicon-floppy-disk"></span> Guardar</button>
						</div>
									
				</div>
				
			</form>
			
			
			</div>
			
			<div class="row">
			<h3>Buscar productos</h3>
			<form class="form-horizontal" name="search_products">	
				<div class="form-group">
					<label class="col-sm-2 control-label"> Nombre producto </label>
						<div class="col-sm-2" >
							<input class="form-control" type = "text"  ng-model="product_search.name" placeholder="ingresa un nombre" >
						</div>
				
						<label class="col-sm-2 control-label"> Categoria </label>
						<div class="col-sm-2">
							<select ng-model="selectedCategory_2" ng-options="item.category_id as item.name for item in category" class="form-control">
							</select>
						</div>
					
						<label class="col-sm-2 control-label"> </label>
						<div class="col-sm-2">
							<button  ng-click="consultar()" class="btn btn-primary"> 
								<span class="glyphicon glyphicon-floppy-disk"></span> Buscar</button>
							</div>
				</div>
			</form>	
			
			</div>
			
			
			<div class="row" style="overflow:scroll; height:300px;">
			
			<table class="table table-hover table-striped">
			 <thead>
			 	<tr>
			 		<th class="text-center">Nombre</th>
			 		<th class="text-center">Codigo</th>
			 		<th class="text-center">Existencia</th>
					<th class="text-center">Precio</th>
					<th class="text-center">Categoria</th>
			 		<th class="text-center"><span class="glyphicon glyphicon-pencil"></span></th>
			 		<th class="text-center"><span class="glyphicon glyphicon-trash"></span></th>
			 	</tr>
			 </thead>

			 <tbody>
				    
			 	    <tr ng-repeat="t in products">
					<td class="text-center" style="display:none;"><input class="form-control" 
					type = "text"  ng-model="t.product_id"></td>
			 		<td class="text-center"><input class="form-control" 
					type = "text"  ng-model="t.name" disabled></td>
			 		<td class="text-center"><input class="form-control" 
					type = "text"  ng-model="t.bar_code" disabled></td>
					<td class="text-center"><input class="form-control" 
					type = "text"  ng-model="t.inventary" disabled></td>
					<td class="text-center"><input class="form-control" 
					type = "text"  ng-model="t.price"></td>	
					<td class="text-center"><input class="form-control" 
					type = "text"  ng-model="t.category_id"></td>						
			 		<td class="text-center"><button ng-click="modificar(t)" class="btn btn-success">
					<span class="glyphicon glyphicon-pencil"></span></button></td>
			 		<td class="text-center"><button ng-click="eliminar(t)" class="btn btn-danger">
					<span class="glyphicon glyphicon-trash"></span></button></td>
			 	</tr>
			 </tbody>	
			</table>

			</div>
		</div>
		
	</body>
	<?php require_once 'pie.php'; ?>