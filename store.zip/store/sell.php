<?php require_once 'encabezado.php'; ?>
<script src="./controlador/topic.js"></script>
<body ng-controller="topicCtrl">
	<div id="content" >
		<div class="row">
			<h3 >Ingresa los datos para registrar un tema</h1>
			<form class="form-horizontal" name="user2">	
				<div class="form-group">
					<label class="col-sm-2 control-label"> Temas </label>
					
					<div class="col-sm-2" >
						<input class="form-control" type = "text"  ng-model="topic.topic_name" placeholder="Nombre del tema" required>
					</div>
					<label class="col-sm-2 control-label"> Curso </label>
					<div class="col-sm-2" >
						<select ng-model="course" ng-options="item as item.name_course for item in courses track by item.course_id" class="form-control">
							<option value="">-- Elije un curso --</option>
						</select>	
					</div>
					
					<div class="col-sm-2">
						<button  ng-click="guardar()" class="btn btn-primary"> 
							<span class="glyphicon glyphicon-floppy-disk"></span> Guardar</button>
						</div>
				</div>
			</form>
			
			<table class="table table-hover table-striped">
			 <thead>
			 	<tr>
			 		<th class="text-center">Nombre tema</th>
			 		<th class="text-center">Codigo curso</th>
			 		<th class="text-center"><span class="glyphicon glyphicon-pencil"></span></th>
			 		<th class="text-center"><span class="glyphicon glyphicon-trash"></span></th>
			 	</tr>
			 </thead>

			 <tbody>
			 	<tr ng-repeat="t in topics">
			 		<td class="text-center"><input class="form-control" 
					type = "text"  ng-model="t.topic_name"></td>
			 		<td class="text-center"><input class="form-control" 
					type = "text"  ng-model="t.topic_course_id" disabled></td>
			 		<td class="text-center"><button ng-click="modificar(t)" class="btn btn-success">
					<span class="glyphicon glyphicon-pencil"></span></button></td>
			 		<td class="text-center"><button ng-click="eliminar(t)" class="btn btn-danger">
					<span class="glyphicon glyphicon-trash"></span></button></td>
			 	</tr>
			 </tbody>	
			</table>

			</div>
		</div>
	</body>
	<?php require_once 'pie.php'; ?>