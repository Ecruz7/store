<?php require_once 'encabezado.php'; ?>
<script src="./controlador/index.js"></script>
<body ng-controller="usuarioCtrl">

 <div id="content" >
  <h1>Administracion</h1>
 

 <div class ="row">
 
  <div class="col-md-12 text-center">
   <h2>¡Bienvenido!</h2>
   
    
  </div>

  <div class="col-md-12 text-center">
    <div class="col-md-4 text-center">  
     <img src="./img/AMM0.png" class="img-responsive">
   </div>
   <div class="col-md-8 text-center">  
    <img src="./img/AMM1.png" class="img-responsive">
   </div>
  </div>

 </div>
 
 
 </div>
</body>
<?php require_once 'pie.php'; ?>