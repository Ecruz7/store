<?php require_once 'encabezado.php'; ?>
<script src="./controlador/activity.js"></script>
<body ng-controller="activityCtrl">
	<?php
    if (isset($_SESSION['message']) && $_SESSION['message'])
    {
      printf('<b>%s</b>', $_SESSION['message']);
      unset($_SESSION['message']);
    }
	?>
	<div id="content" >
		<div class="row">
			<h4 >Ingresa los datos para registrar un tema</h4>
			<form class="form-horizontal" name="user2">	
				<div class="form-group">
					<label class="col-sm-2 control-label"> Temas </label>
					<div class="col-sm-2" >
						<select ng-model="activity1" ng-options="item as item.topic_name for item in topics track by item.topic_id" class="form-control">
							<option value="">-- Elije un tema --</option>
						</select>	
					</div>
					<label class="col-sm-2 control-label"> Tipo de Actividad </label>
					<div class="col-sm-2">
						<select ng-model="activity2" ng-options="item as item.type_activity_name for item in activity_types track by item.activity_type_id" class="form-control">
							<option value="">-- Elije un tipo de actividad --</option>
						</select>
					</div>	
					<div class="col-sm-2" >
						<input class="form-control" type = "text"  ng-model="activity.activity_name" placeholder="Nombre de la actividad" required>
					</div>					
					<div class="col-sm-2">
						<button  ng-click="guardar()" class="btn btn-primary"> 
						<span class="glyphicon glyphicon-floppy-disk"></span> Guardar</button>
					</div>
				</div>
			</form>
			
			<h4>Una vez definida la actividad, suba el archivo que contendrán las preguntas y sus posibles respuestas. Los archivos deben estar en formato Json</h4>
			
			<table class="table table-hover table-striped">
			 <thead>
			 	<tr>
			 		<th class="text-center">Nombre de la actividad</th>
					<th class="text-center">Cuestionario</th>
			 		<th class="text-center"><span class="glyphicon glyphicon-pencil"></span></th>
			 		<th class="text-center"><span class="glyphicon glyphicon-trash"></span></th>
			 	</tr>
			 </thead>

			 <tbody>
			 	<tr ng-repeat="ac in activities">
			 		<td class="text-center"><input class="form-control" 
					type = "text"  ng-model="ac.activity_name"></td>
					<td class="text-horizontal">
					 <form method="POST" action="upload.php" enctype="multipart/form-data">
						<input type="file" name="uploadedFile" />
						<input type="hidden" ng-value="ac.fk_activity_type_id" name="activity_type"/>
						<input type="submit" name="uploadBtn" value="Upload" />
					</form>
					</td>
			 		<td class="text-center"><button ng-click="modificar(ac)" class="btn btn-success">
					<span class="glyphicon glyphicon-pencil"></span></button></td>
			 		<td class="text-center"><button ng-click="eliminar(ac)" class="btn btn-danger">
					<span class="glyphicon glyphicon-trash"></span></button></td>
					
					
			 	</tr>
			 </tbody>	
			</table>

			</div>
		</div>
	</body>
	<?php require_once 'pie.php'; ?>