var App = angular.module('app',[]);

App.controller('topicCtrl', function($scope,$http){

$scope.topic={};
$scope.topics=[];
$scope.courses=[];
$scope.course={};

$scope.guardar = function(){
	
	$scope.topic.topic_course_id=$scope.course.course_id;
	$http.post('./modelo/guardarTopic.php',$scope.topic)
	.success(function(data,status,headers,config){
		$scope.topic={};
		$scope.consultar();
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.consultar = function(){
	$http.post('./modelo/consultarTopics.php')
	.success(function(data,status,headers,config){
		$scope.topics=data;
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.consultar_courses = function(){
	$http.post('./modelo/consultarCourses.php')
	.success(function(data,status,headers,config){
		$scope.courses=data;
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.modificar = function(t){
	$http.post('./modelo/modificarTopic.php',t)
	.success(function(data,status,headers,config){
		$scope.consultar();
		alert(data+"");
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.eliminar = function(t){
	var msn=confirm("Desea eliminar el registro?");
	if(msn){
	$http.post('./modelo/eliminarTopic.php',t)
	.success(function(data,status,headers,config){
		$scope.consultar();
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
	}
}


$scope.consultar();
$scope.consultar_courses();

});