var App = angular.module('app',[]);

App.controller('ActivityTypeCtrl', function($scope,$http){

$scope.activity_type={};
$scope.activity_types=[];

$scope.guardar = function(){
	$http.post('./modelo/guardarActivityType.php',$scope.activity_type)
	.success(function(data,status,headers,config){
		$scope.activity_type={};
		$scope.consultar();
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.consultar = function(){
	$http.post('./modelo/consultarActivityTypes.php')
	.success(function(data,status,headers,config){
		$scope.activity_types=data;
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.modificar = function(act){
	$http.post('./modelo/modificarActivityType.php',act)
	.success(function(data,status,headers,config){
		$scope.consultar();
		alert(data+"");
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.eliminar = function(act){
	var msn=confirm("Desea eliminar el registro?");
	if(msn){
	$http.post('./modelo/eliminarActivityType.php',act)
	.success(function(data,status,headers,config){
		$scope.consultar();
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
	}
}


$scope.consultar();

});