var App = angular.module('app',[]);

App.controller('userStoreCtrl', function($scope,$http){

$scope.store_user={};
$scope.store_users=[];

$scope.save = function(){
	$http.post('./modelo/saveStoreUser.php',$scope.store_user)
	.success(function(data,status,headers,config){
		$scope.store_user={};
		$scope.consultar();
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.consult = function(){
	$http.post('./modelo/consultStoreUsers.php')
	.success(function(data,status,headers,config){
		$scope.store_users=data;
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.edit = function(u){
	$http.post('./modelo/modificarUsuario.php',u)
	.success(function(data,status,headers,config){
		$scope.consultar();
		alert(data+"");
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}


$scope.delete = function(u){
	var msn=confirm("Desea eliminar el registro?");
	if(msn){
	$http.post('./modelo/eliminarUsuario.php',u)
	.success(function(data,status,headers,config){
		$scope.consultar();
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
	}
}


$scope.consultar();

});