 var App = angular.module('app',[]);

App.controller('productCtrl', function($scope,$http){
	
$scope.product_search={};
$scope.product={};
$scope.products=[];
$scope.category={};
$scope.unit={};
$scope.selectedUnit={};
$scope.selectedCategory={};
$scope.selectedCategory_2={};
$scope.total=0;

$scope.guardar = function(){
	$scope.product.category_id=$scope.selectedCategory;
	$scope.product.unit_id=$scope.selectedUnit;
	$http.post('./modelo/saveProduct.php',$scope.product)
	.success(function(data,status,headers,config){
		$scope.product={};
		alert(data);
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.consultar = function(){
	$scope.product_search.category_id=$scope.selectedCategory_2;
	$http.post('./modelo/consultProducts.php',$scope.product_search)
	.success(function(data,status,headers,config){
		//$scope.consult_category();
		$scope.clean();
		$scope.products=data;
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.clean = function()
{
	$scope.products=[];
}

$scope.consult_category = function(){
	$http.post('./modelo/consultCategory.php')
	.success(function(data,status,headers,config){
		
		$scope.category=data;
		$scope.selectedCategory = $scope.category[0].category_id;
		$scope.selectedCategory_2 = $scope.category[0].category_id;
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.consultUnit = function(){
	$http.post('./modelo/consultUnit.php')
	.success(function(data,status,headers,config){
		
		$scope.unit=data;
		$scope.selectedUnit = $scope.unit[0].unit_id;
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}


$scope.cobrar = function(){
	$http.post('./modelo/agregarVenta.php',$scope.productos)
	.success(function(data,status,headers,config){
		$scope.productos={};
		$scope.productos=[];
		$scope.total=0;
		alert("Venta completada");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.modificar = function(t){
	$http.post('./modelo/editProduct.php',t)
	.success(function(data,status,headers,config){
		$scope.consultar();
		alert(data+"");
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}


$scope.eliminar_ = function(i){
   var msn = confirm("¿Desea eliminar el "+i.codigo+"?");
   if(msn){
		$scope.productos.splice(i,1);
		$scope.calcular();
	}
  }

$scope.calcular=function(){
	$scope.total=0;
	for(var i=0; i<$scope.productos.length; i++)
	{
		$scope.total=$scope.total+$scope.productos[i].precio;
	}
}

$scope.eliminar = function(t){
	var msn=confirm("Desea eliminar el registro?");
	if(msn){
	$http.post('./modelo/deleteProduct.php',t)
	.success(function(data,status,headers,config){
		$scope.consultar();
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
	}
}


$scope.consult_category();
$scope.consultUnit();

});