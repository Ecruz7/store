var App = angular.module('app',[]);

App.controller('modificarVentaCtrl', function($scope,$http){

$scope.producto={};
$scope.productos=[];
$scope.total=0;

$scope.buscar = function(){
	$http.post('./modelo/consultardetalleVenta.php',$scope.producto)
	.success(function(data,status,headers,config){
		if(!(data.length==0)){
		$scope.productos.push(data);
		$scope.producto={};
		$scope.calcular();
		}
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.cobrar = function(){
	$http.post('./modelo/agregarVenta.php',$scope.productos)
	.success(function(data,status,headers,config){
		$scope.productos={};
		$scope.productos=[];
		$scope.total=0;
		alert("Venta completada");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}


$scope.eliminar = function(i){
   var msn = confirm("¿Desea eliminar el "+i.codigo+"?");
   if(msn){
	    
		$scope.productos.splice(i,1);
		$scope.calcular();
	}
  }

$scope.calcular=function(){
	$scope.total=0;
	for(var i=0; i<$scope.productos.length; i++)
	{
		$scope.total=$scope.total+$scope.productos[i].precio;
	}
}

});