var App = angular.module('app',[]);

App.controller('sellProductCtrl', function($scope,$http){

$scope.box={};
$scope.product={};
$scope.sell={};
$scope.products=[];
$scope.products_search=[];
$scope.total=0;
$scope.current_box_id=0;
var increment=0;
$scope.product.bar_code=0;
$scope.sell.cash=0;
$scope.sell.rest=0;

$scope.addProduct = function(){
	
	//verifico que la cadena o el id traiga una diagonal de ser asi traera una cantidad
	//divido esa informacion separando el id y guardando la cantidad en una variable 
	//y posteriormente se hace la consulta
	
	var x=$scope.product.bar_code.indexOf("/");
	var substrng_granel="";
	var substrng2="";
	
	if(x!=-1){
		var y=($scope.product.bar_code.length-x)*-1;
		substrng_granel=$scope.product.bar_code.slice(y+1);
		substrng2=$scope.product.bar_code.slice(0,y);
		$scope.product.bar_code=substrng2;
		increment=Number(substrng_granel);
	}else
	{
		increment=1;
	}
	
	$http.post('./modelo/consultProduct.php',$scope.product)
	.success(function(data,status,headers,config){
			
		if(!(data.length==0 ) && (data!="null" )){
		$scope.find=false;
		for(var i=0; i<$scope.products.length; i++)
		 {
			 if($scope.products[i].bar_code==data.bar_code){
				 $scope.products[i].amount+=increment;
				 $scope.products[i].total=$scope.products[i].amount*$scope.products[i].price;
				 $scope.find=true
				 break;
			 }
		 }
		
		if(!$scope.find)
		{
		    data.amount=increment;
			data.total=data.price;
		    $scope.products.push(data);
		}
		
		$scope.product={};
		$scope.calcular();
		}
		
		
	
		
		
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.saveSell = function(){
	$scope.sell.user_id=1;
	$scope.sell.total=$scope.total;
	$scope.sell.rest=$scope.sell.cash-$scope.total;
	$http.post('./modelo/saveSell.php',$scope.sell)
	.success(function(data,status,headers,config){
		alert("Su cambio es: "+$scope.sell.rest);
		$scope.total=0;
		$scope.saveProductSell();
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.saveProductSell = function(){
	$http.post('./modelo/saveProductSell.php',$scope.products)
	.success(function(data,status,headers,config){
		$scope.product={};
		$scope.products=[];
		$scope.total=0;
		$scope.sell={};
		//alert(data);
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.operationBox = function(){
	$http.post('./modelo/operationBox.php',$scope.box)
	.success(function(data,status,headers,config){
		$scope.box={};
		alert("Corte iniciado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.consultBox = function(){
	$http.post('./modelo/consultBox.php',$scope.box)
	.success(function(data,status,headers,config){
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.eliminar = function(i){
   var msn = confirm("¿Desea eliminar el "+i.codigo+"?");
   var index=$scope.products.indexOf(i);
   if(msn){
		$scope.products.splice(index,1);
		$scope.calcular();
	}
  }
  
  $scope.consultar = function(){
	$http.post('./modelo/consultProducts.php')
	.success(function(data,status,headers,config){
		//$scope.consult_category();
		$scope.clean();
		$scope.products_search=data;
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}
  
$scope.editProduct = function(i)
	{
    var index=$scope.products.indexOf(i);
	if(i.amount!=0){
   $scope.products[index].amount=i.amount;
    $scope.products[index].total=$scope.products[index].amount*$scope.products[index].price;
	$scope.product={};
	$scope.calcular();
	}
	else
	{
		$scope.products[index].amount=$scope.products[index].amount;
	}
	
	}
  
  $scope.cancellSell = function(){
   var msn = confirm("¿Desea cancelar la venta?");
   if(msn){
	    
		$scope.product={};
		$scope.products=[];
		$scope.total=0;
	}
  }
  
  $scope.clean = function()
{
	$scope.products_search=[];
}

 $scope.setBarcode_input = function(i)
{
	$scope.product.bar_code=i.bar_code;
}

$scope.calcular=function(){
	$scope.total=0;
	for(var i=0; i<$scope.products.length; i++)
	{
		$scope.total=$scope.total+Number($scope.products[i].total);
	}
}

$scope.consultBox();

});