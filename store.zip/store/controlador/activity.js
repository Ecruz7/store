var App = angular.module('app',[]);

App.controller('activityCtrl', function($scope,$http){

$scope.activity={};
$scope.activity1={};
$scope.activity2={};
$scope.activities=[];



$scope.consultar_activity_types = function(){
	$http.post('./modelo/consultarActivityTypes.php')
	.success(function(data,status,headers,config){
		$scope.activity_types=data;
		$scope.selected = $scope.activity_types[0];
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.consultar_topics = function(){
	$http.post('./modelo/consultarTopics.php')
	.success(function(data,status,headers,config){
		$scope.topics=data;
		$scope.selected = $scope.topics[0];
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}


$scope.guardar = function(){
	//se toman datos del objeto que se selecciono del combobox
	$scope.activity.fk_topic_id=$scope.activity1.topic_id;
	$scope.activity.fk_activity_type_id=$scope.activity2.activity_type_id;
	
	$http.post('./modelo/guardarActivity.php',$scope.activity)
	.success(function(data,status,headers,config){
		$scope.activity={};
		$scope.consultar();
		alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.consultar = function(){
	$http.post('./modelo/consultarActivities.php')
	.success(function(data,status,headers,config){
		$scope.activities=data;
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.modificar = function(ac){
	$http.post('./modelo/modificarActivity.php',ac)
	.success(function(data,status,headers,config){
		$scope.consultar();
		alert(data+"");
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
}

$scope.eliminar = function(ac){
	var msn=confirm("Desea eliminar el registro?");
	if(msn){
	$http.post('./modelo/eliminarActivity.php',ac)
	.success(function(data,status,headers,config){
		$scope.consultar();
		//alert("Registrado");
        // setTimeout(function () {$scope.creaU = false;}, 1000);
	}).error(function(data,status,headers,config){
		alert("Error BD" + data);
	});
	}
}


$scope.consultar();
$scope.consultar_activity_types();
$scope.consultar_topics();
});