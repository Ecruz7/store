<?php
 
class DbOperation
{
    //Database connection link
    private $con;
 
    //Class constructor
    function __construct()
    {
        //Getting the DbConnect.php file
        require_once dirname(__FILE__) . '/DBConnect.php';
 
        //Creating a DbConnect object to connect to the database
        $db = new DbConnect();
 
        //Initializing our connection link of this class
        //by calling the method connect of DbConnect class
        $this->con = $db->connect();
    }
	
	function createUser($email,$user_name, $user_password){
	
		$stmt = $this->con->prepare("INSERT INTO user_amm (email,user_name, password) VALUES (?,?,?)");
		$stmt->bind_param("sss", $email,$user_name,$user_password);
		if($stmt->execute())
		{
			return true;
		}else
		{
			return false; 
		}	
	}
	
	function createUserCourse($fk_user_id, $fk_course_id){
		$stmt = $this->con->prepare("INSERT INTO user_course (fk_user_id, fk_course_id) VALUES (?,?)");
		$stmt->bind_param("ii", $fk_user_id,$fk_course_id);
		if($stmt->execute())
			return true; 
		return false; 
	}
 
	
	function getProgressUser($user_id){
				
		$result  = $this->con->query("SELECT progress FROM data_user WHERE user_id ='$user_id'");
		if (!$result ) {
			return  false;
		}
		$data = array(); 		/* obtener un array asociativo */		
		$fila = $result->fetch_assoc();		/* liberar el conjunto de resultados */		
		$result->free();		
		array_push($data, $fila); 				
		return $data ;
	}
	
	function getUser($user_name,$password){
		
		$result  = $this->con->query("SELECT user_id,email,password,user_course_id,fk_course_id,progress FROM data_user WHERE user_name ='$user_name' AND password='$password' ");	
		if (!$result ) {
			return  false;
		}
		$data = array(); 		/* obtener un array asociativo */		
		$fila = $result->fetch_assoc();		/* liberar el conjunto de resultados */		
		$result->free();		
		array_push($data, $fila); 				
		return $data ;
	}
	
	
	function restoreUserserPassword($email){
		 $message="";
		$result  = $this->con->query("SELECT user_id,email,password,user_course_id,fk_course_id,progress FROM data_user WHERE email ='$email'");	
		if (!$result ) {
			return  false;
		}else{
		$data = array(); 		/* obtener un array asociativo */			
		while($fila = mysqli_fetch_array( $result ) )
		{
		  //Ahora $fila tiene la primera fila de la consulta, pongamos que tienes
		  //un campo en tu DB llamado NOMBRE, así accederías
		  $message=$fila['password'];
		}
		$result->free();			
		$to = $email;
		$subject = "Recuperacion de contraseña aplicacion AMM";
		if($message!=""){
		mail($to, $subject, "Tu clave de acceso es : ".$message);
		return true;
		}else{
			return false;
		}
		}
		
	}
	/*
	* The update operation
	* When this method is called the record with the given id is updated with the new given values
	*/
	
}

?>