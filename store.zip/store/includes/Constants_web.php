<?php
	/*
	* Created by Belal Khan
	* website: www.simplifiedcoding.net 
	*/
	define('DB_HOST', 'localhost');
	define('DB_USER', 'id12208447_alvarmat');
	define('DB_PASS', '12345678');
	define('DB_NAME', 'id12208447_amm');
	?>