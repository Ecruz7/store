<?php
 
class DbOperation
{
    //Database connection link
    private $con;
 
    //Class constructor
    function __construct()
    {
        //Getting the DbConnect.php file
        require_once dirname(__FILE__) . '/DBConnect.php';
 
        //Creating a DbConnect object to connect to the database
        $db = new DbConnect();
 
        //Initializing our connection link of this class
        //by calling the method connect of DbConnect class
        $this->con = $db->connect();
    }

	function createUser($user_name, $user_password){
		$stmt = $this->con->prepare("INSERT INTO user_amm (user_name, password) VALUES (?,?)");
		$stmt->bind_param("ss", $user_name,$user_password);
		if($stmt->execute())
			return true; 
		return false; 
	}
 
	/*
	* The read operation
	* When this method is called it is returning all the existing record of the database
	*/
	function getActivities($topic_id,$user_course_id){		
	$data = array(); 
	$result = $this->con->query("SELECT user_activity_id, activity_id,activity_name,activity_status,activity_type,tries 
	FROM vista_activities_user where topic_id='$topic_id' AND user_course_id='$user_course_id'");	
	if (!$result ) 	{			
	return  $result->error();	
	}$data = array(); 		
	
	/* obtener un array asociativo */		
	while ($fila = $result->fetch_assoc()) 	
	{        
		array_push($data, $fila);     
	}		/* liberar el conjunto de resultados */	
	$result->free();											
	return $data ;
	}
	
	/*
	* The update operation
	* When this method is called the record with the given id is updated with the new given values
	*/	
	
	function getQuestions($activity_id,$activity_type_id){
		
		$data = file_get_contents("../contents/$activity_type_id/$activity_id.json");
		$questions = json_decode($data, true);
		$result = array(); 
		foreach ($questions as $question) 
		{
		array_push($result, $question);	
		}
		
		return $questions;	
	}
	
	function getAudioData($activity_id,$activity_type_id){
		
		$data = file_get_contents("../contents/$activity_type_id/$activity_id.json");
		$questions = json_decode($data, true);
		$result = array(); 
		foreach ($questions as $question) 
		{
		array_push($result, $question);	
		}
		
		return $questions;	
	}
	
	function updateActivity($user_activity_id){
		$stmt = $this->con->prepare("UPDATE user_activities SET user_activity_status=1 WHERE user_activity_id=? ");
		$stmt->bind_param("i", $user_activity_id);
		if($stmt->execute())
			return true; 
		return false; 
	}
	
	function updateActivity_tries($user_activity_id, $tries){
		$stmt = $this->con->prepare("UPDATE user_activities SET tries=$tries WHERE user_activity_id=? ");
		$stmt->bind_param("i", $user_activity_id);
		if($stmt->execute())
			return true; 
		return false; 
	}

}

?>