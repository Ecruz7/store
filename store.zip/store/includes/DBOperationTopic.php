<?php
 
class DbOperation
{
    //Database connection link
    private $con;
 
    //Class constructor
    function __construct()
    {
        //Getting the DbConnect.php file
        require_once dirname(__FILE__) . '/DBConnect.php';
 
        //Creating a DbConnect object to connect to the database
        $db = new DbConnect();
 
        //Initializing our connection link of this class
        //by calling the method connect of DbConnect class
        $this->con = $db->connect();
    }
	/*
	* The read operation
	* When this method is called it is returning all the existing record of the database
	*/
	function getTopic($topic_id){
		$result= $this->con->query("SELECT * FROM view_topics WHERE topic_id = $topic_id ");
		if (!$result ) {
			return  false;
		}
		$data = array(); 		/* obtener un array asociativo */		
		$fila = $result->fetch_assoc();		/* liberar el conjunto de resultados */		
		$result->free();		
		array_push($data, $fila); 				
		return $data ;
	}
	
		function getTopics($topic_course_id){	
		$result = $this->con->query("SELECT * FROM view_topics 
		WHERE topic_course_id=$topic_course_id");
		if (!$result ) 			
		{			
			return  "error";					
		}					
		$data = array(); 		/* obtener un array asociativo */				
		while ($fila = $result->fetch_assoc()) 	{
			array_push($data, $fila);     		
			}				/* liberar el conjunto de resultados */			
			$result->free();													
			return $data ;
	}
	
	/*
	* The update operation
	* When this method is called the record with the given id is updated with the new given values
	*/
	function updateTopic($topic_id, $topic_name, $content_topic){
		$stmt = $this->con->prepare("UPDATE topic SET topic_name = ?, content_topic = ? WHERE topic_id = ?");
		$stmt->bind_param("ssisi", $topic_name, $content_topic, $id);
		if($stmt->execute())
			return true; 
		return false; 
	}
}

?>