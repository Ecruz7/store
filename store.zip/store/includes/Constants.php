<?php
	/*
	* Created by Belal Khan
	* website: www.simplifiedcoding.net 
	*/
	
	define('DB_HOST', 'fdb3.awardspace.net');
	define('DB_USER', '1578544_amm');
	define('DB_PASS', 'personaje0101');
	define('DB_NAME', '1578544_amm');
	?>