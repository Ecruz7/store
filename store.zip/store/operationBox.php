<?php require_once 'encabezado.php'; ?>
<script src="./controlador/sell_product.js"></script>
<body ng-controller="sellProductCtrl">
	<div id="content" >
		<div class="row">
			<h3>Corte de caja</h1>
			<form class="navbar-form navbar-center" name="user2">	
			    <div class="form-group">
					<div class="input-group">
						<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
						<input type="text" class="form-control" ng-model="box.user_name" placeholder="Usuario" required>
					</div>
		            <div class="input-group">
		         	 <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
			         <input type="password" class="form-control" ng-model="box.password" placeholder="Contraseña" required>
                    </div>
			    </div>
								
				<div class="form-group">
					
					<div class="input-group" >
						<span class="input-group-addon"><i class="glyphicon glyphicon-usd"></i></span>
						<input class="form-control" type = "text"  ng-model="box.cash" placeholder="monto de inicio" required>
					</div>
					<div class="input-group">
						<button  ng-click="operationBox()" class="btn btn-primary"> 
							<span class="glyphicon glyphicon-floppy-disk"></span> Corte de caja</button>
					</div>
				

				</div>
			</form>


			</div>
		</div>
	</body>
	<?php require_once 'pie.php'; ?>